// proxy.rs - SOCKS5 Proxy with Automatic Domestic Fronting Failover
use tokio::net::{TcpListener, TcpStream};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use std::net::SocketAddr;
use std::error::Error;
use std::sync::Arc;
use reqwest::Client;
use reqwest::header::{HeaderMap, HeaderValue, HOST};
use tauri::{AppHandle, Emitter};

use crate::crypto::CryptoEngine;
use crate::protocol::PolymorphicProtocol;

pub struct LocalProxy {
    bind_addr: SocketAddr,
    gateway_url: String,
    crypto: Arc<CryptoEngine>,
    protocol: Arc<PolymorphicProtocol>,
    app: AppHandle,
}

impl LocalProxy {
    pub fn new(
        port: u16,
        gateway_url: String,
        crypto: Arc<CryptoEngine>,
        protocol: Arc<PolymorphicProtocol>,
        app: AppHandle,
    ) -> Self {
        Self {
            bind_addr: SocketAddr::from(([127, 0, 0, 1], port)),
            gateway_url,
            crypto,
            protocol,
            app,
        }
    }

    pub async fn start_listener(&self) -> Result<(), Box<dyn Error + Send + Sync>> {
        let listener = TcpListener::bind(self.bind_addr).await?;
        let _ = self.app.emit("log-event", format!("[INFO] SOCKS5 Proxy active on port {}", self.bind_addr.port()));

        loop {
            match listener.accept().await {
                Ok((socket, addr)) => {
                    let gateway_url = self.gateway_url.clone();
                    let crypto = Arc::clone(&self.crypto);
                    let protocol = Arc::clone(&self.protocol);
                    let app_handle = self.app.clone();

                    tokio::spawn(async move {
                        if let Err(e) = Self::handle_socks5_client(socket, gateway_url, crypto, protocol, app_handle).await {
                            eprintln!("[WARN] Connection dropped: {}", e);
                        }
                    });
                }
                Err(e) => {
                    let _ = self.app.emit("log-event", format!("[ERROR] Socket accept failed: {}", e));
                }
            }
        }
    }

    async fn handle_socks5_client(
        mut socket: TcpStream,
        gateway_url: String,
        crypto: Arc<CryptoEngine>,
        protocol: Arc<PolymorphicProtocol>,
        app: AppHandle,
    ) -> Result<(), Box<dyn Error + Send + Sync>> {
        let mut header = [0u8; 2];
        socket.read_exact(&mut header).await?;

        if header[0] != 0x05 {
            return Err("Invalid SOCKS version".into());
        }

        let nmethods = header[1];
        let mut methods = vec![0u8; nmethods as usize];
        socket.read_exact(&mut methods).await?;

        socket.write_all(&[0x05, 0x00]).await?;
        socket.flush().await?;

        let mut req_header = [0u8; 4];
        socket.read_exact(&mut req_header).await?;

        let cmd = req_header[1];
        let atyp = req_header[3];

        if cmd != 0x01 {
            socket.write_all(&[0x05, 0x07, 0x00, 0x01, 0, 0, 0, 0, 0, 0]).await?;
            return Err("Command unsupported".into());
        }

        let target_dest = match atyp {
            0x01 => {
                let mut ip = [0u8; 4];
                socket.read_exact(&mut ip).await?;
                let mut port_bytes = [0u8; 2];
                socket.read_exact(&mut port_bytes).await?;
                let port = u16::from_be_bytes(port_bytes);
                format!("{}.{}.{}.{}:{}", ip[0], ip[1], ip[2], ip[3], port)
            }
            0x03 => {
                let len = socket.read_u8().await? as usize;
                let mut domain = vec![0u8; len];
                socket.read_exact(&mut domain).await?;
                let domain_str = String::from_utf8(domain)?;
                let mut port_bytes = [0u8; 2];
                socket.read_exact(&mut port_bytes).await?;
                let port = u16::from_be_bytes(port_bytes);
                format!("{}:{}", domain_str, port)
            }
            _ => {
                socket.write_all(&[0x05, 0x08, 0x00, 0x01, 0, 0, 0, 0, 0, 0]).await?;
                return Err("Unsupported address type".into());
            }
        };

        let _ = app.emit("log-event", format!("[PROXY] Intercepted request targeting: {}", target_dest));

        socket.write_all(&[0x05, 0x00, 0x00, 0x01, 127, 0, 0, 1, 0, 0]).await?;
        socket.flush().await?;

        Self::pipe_to_cloudflare(socket, target_dest, gateway_url, crypto, protocol, app).await?;

        Ok(())
    }

    /// Pipes SOCKS5 traffic with automated dynamic domestic failover routing
    async fn pipe_to_cloudflare(
        client_stream: TcpStream,
        target: String,
        gateway_url: String,
        crypto: Arc<CryptoEngine>,
        protocol: Arc<PolymorphicProtocol>,
        app: AppHandle,
    ) -> Result<(), Box<dyn Error + Send + Sync>> {
        let (mut client_reader, mut client_writer) = client_stream.into_split();
        let client_http = Client::builder()
            .timeout(std::time::Duration::from_secs(3)) // 3 seconds timeout to quickly trigger failover
            .build()?;

        let auth_token = crypto.generate_auth_token();

        let mut headers = HeaderMap::new();
        headers.insert("X-Void-Auth", HeaderValue::from_str(&auth_token)?);
        headers.insert("X-Target-Dest", HeaderValue::from_str(&target)?);

        tokio::spawn(async move {
            let mut buf = vec![0u8; 8192];
            
            loop {
                match client_reader.read(&mut buf).await {
                    Ok(0) => break,
                    Ok(n) => {
                        let payload_chunk = &buf[..n];
                        let mut temp_buffer = Vec::new();
                        
                        let _ = protocol.send_secure_frame(&mut temp_buffer, payload_chunk).await;

                        // 1. First Attempt: Direct Anycast Cloudflare Worker POST request
                        let mut _res = client_http.post(&gateway_url)
                            .headers(headers.clone())
                            .body(temp_buffer.clone())
                            .send()
                            .await;
                            
                        // 2. Dynamic Failover Strategy: If primary direct connection drops or times out
                        if _res.is_err() {
                            let _ = app.emit("log-event", "[WARN] Primary link degraded. Executing Dynamic Domestic Fronting failover...".to_string());
                            
                            // Retrieve the fallback domestic CDN or SNI host
                            let domestic_mirror = "https://104.16.0.1"; // Default stable Cloudflare fronting IP if custom is empty
                            
                            // Parse host domain for header spoofing
                            let parsed_url = url::Url::parse(&gateway_url).unwrap();
                            let host_header_val = parsed_url.host_str().unwrap_or("void-tunnel-edge.yourdomain.workers.dev");

                            let mut spoof_headers = headers.clone();
                            // Spoof the Host header to trick the domestic DPI
                            spoof_headers.insert(HOST, HeaderValue::from_str(host_header_val).unwrap());

                            // Shoot the payload disguised as a domestic TLS query
                            _res = client_http.post(domestic_mirror)
                                .headers(spoof_headers)
                                .body(temp_buffer)
                                .send()
                                .await;
                        }
                            
                        if let Ok(res_body) = _res {
                            if let Ok(bytes) = res_body.bytes().await {
                                let _ = client_writer.write_all(&bytes).await;
                                let _ = client_writer.flush().await;
                            }
                        }
                    }
                    Err(_) => break,
                }
            }
        });

        Ok(())
    }
}