// protocol.rs - Generic Polymorphic Transport Protocol and Flow Obfuscation Engine
use crate::crypto::CryptoEngine;
use tokio::io::{AsyncRead, AsyncReadExt, AsyncWrite, AsyncWriteExt};
use rand::{Rng, thread_rng};
use std::error::Error;
use std::sync::Arc;

pub struct PolymorphicProtocol {
    crypto: Arc<CryptoEngine>,
    min_padding: usize,
    max_padding: usize,
}

impl PolymorphicProtocol {
    pub fn new(crypto: Arc<CryptoEngine>, min_padding: usize, max_padding: usize) -> Self {
        Self {
            crypto,
            min_padding,
            max_padding,
        }
    }

    /// Encapsulates raw payload into a polymorphic frame with cryptographically secure padding
    pub async fn send_secure_frame<W>(
        &self,
        writer: &mut W,
        payload: &[u8]
    ) -> Result<(), Box<dyn Error + Send + Sync>>
    where
        W: AsyncWrite + Unpin,
    {
        // 1. Generate unique 12-byte nonce for ChaCha20-Poly1305
        let mut nonce = [0u8; 12];
        thread_rng().fill(&mut nonce);

        // 2. Encrypt the raw application payload
        let encrypted_data = self.crypto.encrypt_payload(payload, &nonce)?;
        let encrypted_len = encrypted_data.len();

        if encrypted_len > 65535 {
            return Err("Encrypted payload length exceeds protocol frame boundaries".into());
        }

        // 3. Determine random statistical noise padding size
        let padding_len = thread_rng().gen_range(self.min_padding..=self.max_padding);
        let padding_bytes = CryptoEngine::generate_secure_bytes(padding_len);

        // 4. Assemble binary frame structure:
        // [2 Bytes: Payload Length] [12 Bytes: Nonce] [Variable: Encrypted Payload] [Variable: Statistical Noise]
        let mut frame = Vec::with_capacity(2 + 12 + encrypted_len + padding_len);
        frame.extend_from_slice(&(encrypted_len as u16).to_be_bytes());
        frame.extend_from_slice(&nonce);
        frame.extend_from_slice(&encrypted_data);
        frame.extend_from_slice(&padding_bytes);

        // 5. Stream the assembled frame down the writer
        writer.write_all(&frame).await?;
        writer.flush().await?;

        Ok(())
    }

    /// Dismantles Signature-based DPI by injecting jitter and non-linear fragmentation during handshake phase
    pub async fn send_fragmented_handshake<W>(
        &self,
        writer: &mut W,
        handshake_payload: &[u8]
    ) -> Result<(), Box<dyn Error + Send + Sync>>
    where
        W: AsyncWrite + Unpin,
    {
        let mut rng = thread_rng();
        let mut offset = 0;
        let total_size = handshake_payload.len();

        while offset < total_size {
            let chunk_size = rng.gen_range(1..=16).min(total_size - offset);
            let next_offset = offset + chunk_size;

            writer.write_all(&handshake_payload[offset..next_offset]).await?;
            writer.flush().await?;

            offset = next_offset;

            let delay_ms = rng.gen_range(1..=5);
            tokio::time::sleep(tokio::time::Duration::from_millis(delay_ms)).await;
        }

        Ok(())
    }

    /// Read and reconstruct incoming secure frames from the Serverless Edge Gatekeeper
    pub async fn read_secure_frame<R>(
        &self,
        reader: &mut R
    ) -> Result<Vec<u8>, Box<dyn Error + Send + Sync>>
    where
        R: AsyncRead + Unpin,
    {
        let mut len_buffer = [0u8; 2];
        reader.read_exact(&mut len_buffer).await?;
        let payload_len = u16::from_be_bytes(len_buffer) as usize;

        let mut nonce = [0u8; 12];
        reader.read_exact(&mut nonce).await?;

        let mut encrypted_buffer = vec![0u8; payload_len];
        reader.read_exact(&mut encrypted_buffer).await?;

        let decrypted_data = self.crypto.decrypt_payload(&encrypted_buffer, &nonce)?;

        Ok(decrypted_data)
    }
}