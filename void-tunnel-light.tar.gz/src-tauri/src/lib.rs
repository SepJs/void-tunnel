// lib.rs - Core Library Entrypoint for Tauri v2 Shared Infrastructure
pub mod proxy;
pub mod crypto;
pub mod protocol;
pub mod evasion;
pub mod deploy;
pub mod killswitch;

use std::sync::Arc;
use tauri::{AppHandle, Emitter};
use crate::proxy::LocalProxy;
use crate::deploy::CloudflareDeployer;
use crate::killswitch::KillSwitch;
use crate::crypto::CryptoEngine;
use crate::protocol::PolymorphicProtocol;
use crate::evasion::EvasionManager;

struct AppState {
    killswitch: Arc<KillSwitch>,
}

#[tauri::command]
async fn deploy_tunnel_via_token(
    api_token: String,
    secret_key_hex: String,
) -> Result<String, String> {
    let deployer = CloudflareDeployer::new(api_token);
    
    if !deployer.verify_token().await.map_err(|e| e.to_string())? {
        return Err("Cloudflare authentication token verification failed".to_string());
    }

    let account_id = deployer.get_account_id()
        .await
        .map_err(|e| e.to_string())?;

    let endpoint = deployer.deploy_gatekeeper(&account_id, &secret_key_hex)
        .await
        .map_err(|e| e.to_string())?;

    Ok(endpoint)
}

#[tauri::command]
async fn start_tunnel(
    app: AppHandle,
    port: u16,
    gateway_url: String,
    secret_key_hex: String,
    region_code: String,
    spoof_mac: String,
    domestic_fallback: String,
) -> Result<String, String> {
    let raw_key = match hex_to_bytes(&secret_key_hex) {
        Ok(bytes) => {
            if bytes.len() != 32 {
                return Err("Cryptographic key must be exactly 32-bytes (64 characters)".to_string());
            }
            let mut key = [0u8; 32];
            key.copy_from_slice(&bytes);
            key
        }
        Err(e) => return Err(format!("Hex decode error: {}", e)),
    };

    let crypto = Arc::new(CryptoEngine::new(&raw_key));
    let profile = EvasionManager::get_profile_by_region(&region_code);
    let protocol = Arc::new(PolymorphicProtocol::new(
        Arc::clone(&crypto),
        profile.min_padding,
        profile.max_padding
    ));

    let app_clone = app.clone();
    let _ = app.emit("log-event", format!("[SYSTEM] Arming SOCKS5 Tunnel with {} profile...", profile.name));
    let _ = app.emit("log-event", format!("[SYSTEM] Spoofing MAC: {} | Failover IP: {}", spoof_mac, domestic_fallback));

    tokio::spawn(async move {
        let proxy = LocalProxy::new(port, gateway_url, crypto, protocol, app_clone);
        if let Err(e) = proxy.start_listener().await {
            let _ = app.emit("log-event", format!("[ERROR] SOCKS5 Listener failed: {}", e));
        }
    });

    Ok(format!("SOCKS5 Tunnel active on port {}", port))
}

#[tauri::command]
async fn toggle_killswitch(
    active: bool,
    state: tauri::State<'_, AppState>
) -> Result<String, String> {
    if active {
        state.killswitch.activate().map_err(|e| e.to_string())?;
        Ok("strict_lock_active".to_string())
    } else {
        state.killswitch.deactivate().map_err(|e| e.to_string())?;
        Ok("strict_lock_inactive".to_string())
    }
}

fn hex_to_bytes(hex: &str) -> Result<Vec<u8>, String> {
    let clean_hex = hex.trim();
    if clean_hex.len() % 2 != 0 {
        return Err("Hex string must have an even length".to_string());
    }
    (0..clean_hex.len())
        .step_by(2)
        .map(|i| {
            u8::from_str_radix(&clean_hex[i..i + 2], 16)
                .map_err(|e| e.to_string())
        })
        .collect()
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let killswitch_instance = Arc::new(KillSwitch::new());
    let state = AppState {
        killswitch: killswitch_instance,
    };

    tauri::Builder::default()
        .manage(state)
        .invoke_handler(tauri::generate_handler![
            deploy_tunnel_via_token,
            start_tunnel,
            toggle_killswitch
        ])
        .run(tauri::generate_context!())
        .expect("Error while compiling and launching Void-Tunnel execution runtime");
}