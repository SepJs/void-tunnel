// killswitch.rs - System-Wide Kernel & Interface Traffic Lock Engine
use std::process::Command;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

pub struct KillSwitch {
    is_active: Arc<AtomicBool>,
}

impl KillSwitch {
    pub fn new() -> Self {
        Self {
            is_active: Arc::new(AtomicBool::new(false)),
        }
    }

    /// Triggers the system-wide firewall/routing lock based on target OS
    pub fn activate(&self) -> Result<(), String> {
        if self.is_active.load(Ordering::SeqCst) {
            return Ok(());
        }

        println!("[KILLSWITCH] Strict Mode active. Locking down outbound system network paths...");
        self.is_active.store(true, Ordering::SeqCst);

        #[cfg(target_os = "windows")]
        {
            let _ = Command::new("netsh")
                .args(&["advfirewall", "firewall", "add", "rule", "name=VoidTunnelBlock", "dir=out", "action=block"])
                .output();
        }

        #[cfg(target_os = "linux")]
        {
            let _ = Command::new("iptables")
                .args(&["-A", "OUTPUT", "-j", "DROP"])
                .output();
        }

        #[cfg(target_os = "macos")]
        {
            let _ = Command::new("pfctl")
                .args(&["-d"])
                .output();
        }

        Ok(())
    }

    /// Safely releases firewall blocks and restores original system routing tables
    pub fn deactivate(&self) -> Result<(), String> {
        if !self.is_active.load(Ordering::SeqCst) {
            return Ok(());
        }

        println!("[KILLSWITCH] Restoring system interfaces and routing paths...");
        self.is_active.store(false, Ordering::SeqCst);

        #[cfg(target_os = "windows")]
        {
            let _ = Command::new("netsh")
                .args(&["advfirewall", "firewall", "delete", "rule", "name=VoidTunnelBlock"])
                .output();
        }

        #[cfg(target_os = "linux")]
        {
            let _ = Command::new("iptables")
                .args(&["-D", "OUTPUT", "-j", "DROP"])
                .output();
        }

        #[cfg(target_os = "macos")]
        {
            let _ = Command::new("pfctl")
                .args(&["-e"])
                .output();
        }

        Ok(())
    }

    /// Query active operational status of the lock system
    pub fn is_locked(&self) -> bool {
        self.is_active.load(Ordering::SeqCst)
    }
}

impl Drop for KillSwitch {
    fn drop(&mut self) {
        let _ = self.deactivate();
    }
}