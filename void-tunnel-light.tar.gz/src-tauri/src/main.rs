// main.rs - Executable Entrypoint redirecting to Shared Library
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    void_tunnel_lib::run();
}