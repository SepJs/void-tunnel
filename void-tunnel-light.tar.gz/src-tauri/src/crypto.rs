// crypto.rs - Symmetric Cryptography and HMAC Handshake Validation Engine
use chacha20poly1305::{ChaCha20Poly1305, Key, Nonce};
use chacha20poly1305::aead::{Aead, KeyInit};
use ring::hmac;
use std::time::{SystemTime, UNIX_EPOCH};
use std::error::Error;
use rand::{Rng, thread_rng};

pub struct CryptoEngine {
    chacha_key: Key,
    hmac_key: hmac::Key,
}

impl CryptoEngine {
    /// Initializes cryptographic engine with 256-bit keys
    pub fn new(raw_key: &[u8; 32]) -> Self {
        let chacha_key = Key::clone_from_slice(raw_key);
        let hmac_key = hmac::Key::new(hmac::HMAC_SHA256, raw_key);
        
        Self {
            chacha_key,
            hmac_key,
        }
    }

    /// Generates a drift-compensated HMAC-SHA256 validation token
    pub fn generate_auth_token(&self) -> String {
        let current_time = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        
        // Calculate the base time step (30 seconds window)
        let time_step = current_time / 30;
        let message = time_step.to_string();

        let signature = hmac::sign(&self.hmac_key, message.as_bytes());
        
        // Return URL-safe Base64 encoded signature token
        base64::Engine::encode(
            &base64::prelude::BASE64_URL_SAFE_NO_PAD,
            signature.as_ref()
        )
    }

    /// Encrypts raw network payloads using ChaCha20-Poly1305 with an explicit, unique nonce
    pub fn encrypt_payload(
        &self,
        payload: &[u8],
        nonce_bytes: &[u8; 12]
    ) -> Result<Vec<u8>, Box<dyn Error + Send + Sync>> {
        let cipher = ChaCha20Poly1305::new(&self.chacha_key);
        let nonce = Nonce::from_slice(nonce_bytes);

        let ciphertext = cipher.encrypt(nonce, payload)
            .map_err(|_| "Symmetric encryption failure inside AEAD block")?;
            
        Ok(ciphertext)
    }

    /// Decrypts encapsulated network blocks, verifying integrity tags before release
    pub fn decrypt_payload(
        &self,
        ciphertext: &[u8],
        nonce_bytes: &[u8; 12]
    ) -> Result<Vec<u8>, Box<dyn Error + Send + Sync>> {
        let cipher = ChaCha20Poly1305::new(&self.chacha_key);
        let nonce = Nonce::from_slice(nonce_bytes);

        let plaintext = cipher.decrypt(nonce, ciphertext)
            .map_err(|_| "Symmetric decryption or authentication verification failed")?;
            
        Ok(plaintext)
    }

    /// Helper utility to generate cryptographically secure random bytes
    pub fn generate_secure_bytes(length: usize) -> Vec<u8> {
        let mut buffer = vec![0u8; length];
        thread_rng().fill(&mut buffer[..]);
        buffer
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_encryption_decryption_cycle() {
        let raw_key = [0u8; 32];
        let engine = CryptoEngine::new(&raw_key);
        let raw_data = b"Innocent transit metadata payload";
        
        let mut nonce = [0u8; 12];
        thread_rng().fill(&mut nonce);

        let encrypted = engine.encrypt_payload(raw_data, &nonce).unwrap();
        let decrypted = engine.decrypt_payload(&encrypted, &nonce).unwrap();

        assert_eq!(raw_data.to_vec(), decrypted);
    }
}