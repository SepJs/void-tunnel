// deploy.rs - Automated Cloudflare OAuth Authentication and Deployment Engine
use reqwest::header::{HeaderMap, HeaderValue, AUTHORIZATION};
use serde::Deserialize;
use std::error::Error;
use std::net::SocketAddr;
use std::io::{Read, Write};
use socket2::{Socket, Domain, Type, Protocol};

// Cloudflare Official Wrangler OAuth Client ID (Publicly Available)
const WRANGLER_CLIENT_ID: &str = "545b3a3e-63f5-4cf6-ba97-e818816c4a45";
// Cloudflare registers Wrangler's redirect callback exclusively on port 8976
const REDIRECT_URI: &str = "http://localhost:8976/oauth/callback";

#[derive(Deserialize)]
struct TokenResponse {
    access_token: String,
}

pub struct CloudflareDeployer {
    api_token: String,
    client: reqwest::Client,
}

impl CloudflareDeployer {
    pub fn new(api_token: String) -> Self {
        Self {
            api_token,
            client: reqwest::Client::new(),
        }
    }

    /// Verifies if the provided API token is valid
    pub async fn verify_token(&self) -> Result<bool, Box<dyn Error + Send + Sync>> {
        let mut headers = HeaderMap::new();
        let auth_val = format!("Bearer {}", self.api_token);
        headers.insert(AUTHORIZATION, HeaderValue::from_str(&auth_val)?);

        let res = self.client
            .get("https://api.cloudflare.com/client/v4/user/tokens/verify")
            .headers(headers)
            .send()
            .await?;

        Ok(res.status().is_success())
    }

    /// Spawns a temporary local web server with socket-reuse capabilities and listens for OAuth redirect
    pub async fn login_via_oauth() -> Result<String, Box<dyn Error + Send + Sync>> {
        let auth_url = format!(
            "https://dash.cloudflare.com/oauth2/auth?client_id={}&redirect_uri={}&response_type=code&scope=account%3Aread%20user%3Aread%20workers%3Awrite&state=void",
            WRANGLER_CLIENT_ID,
            urlencoding::encode(REDIRECT_URI)
        );

        println!("[OAUTH] Launching browser: {}", auth_url);
        let _ = open::that(auth_url);

        // Bind raw socket enabling instant address and port reuse to bypass "address already in use" errors
        let socket_addr: SocketAddr = "127.0.0.1:8976".parse()?;
        let socket = Socket::new(Domain::for_address(socket_addr), Type::STREAM, Some(Protocol::TCP))?;
        socket.set_reuse_address(true)?;
        
        #[cfg(not(target_os = "windows"))]
        socket.set_reuse_port(true)?;

        socket.bind(&socket_addr.into())?;
        socket.listen(128)?;

        // Convert the socket2 raw handle cleanly back to a standard library TcpListener
        let listener: std::net::TcpListener = socket.into();
        let mut auth_code = String::new();

        if let Ok((mut stream, _)) = listener.accept() {
            let mut buffer = [0u8; 1024];
            let _ = stream.read(&mut buffer)?;

            let request_str = String::from_utf8_lossy(&buffer);
            
            if let Some(code_pos) = request_str.find("code=") {
                let temp = &request_str[code_pos + 5..];
                if let Some(space_pos) = temp.find(' ') {
                    let raw_code = &temp[..space_pos];
                    if let Some(and_pos) = raw_code.find('&') {
                        auth_code = raw_code[..and_pos].to_string();
                    } else {
                        auth_code = raw_code.to_string();
                    }
                }
            }

            let response = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n\
                            <html><body style='font-family:sans-serif; text-align:center; padding-top:50px; background:#000; color:#00F5FF;'>\
                            <h2>VOID-TUNNEL LOGIN SUCCESSFUL</h2>\
                            <p style='color:#8A2BE2;'>You can close this tab now and return to the operator console.</p>\
                            </body></html>";
            let _ = stream.write_all(response.as_bytes());
            let _ = stream.flush();
        }

        if auth_code.is_empty() {
            return Err("OAuth authentication was cancelled or timed out.".into());
        }

        let client = reqwest::Client::new();
        let params = [
            ("grant_type", "authorization_code"),
            ("client_id", WRANGLER_CLIENT_ID),
            ("code", &auth_code),
            ("redirect_uri", REDIRECT_URI),
        ];

        let token_res = client
            .post("https://dash.cloudflare.com/oauth2/token")
            .form(&params)
            .send()
            .await?
            .json::<TokenResponse>()
            .await?;

        Ok(token_res.access_token)
    }

    pub async fn get_account_id(&self) -> Result<String, Box<dyn Error + Send + Sync>> {
        let mut headers = HeaderMap::new();
        let auth_val = format!("Bearer {}", self.api_token);
        headers.insert(AUTHORIZATION, HeaderValue::from_str(&auth_val)?);

        let res = self.client
            .get("https://api.cloudflare.com/client/v4/accounts")
            .headers(headers)
            .send()
            .await?
            .json::<serde_json::Value>()
            .await?;

        let account_id = res["result"][0]["id"]
            .as_str()
            .ok_or("Failed to parse Account ID from Cloudflare response")?;

        Ok(account_id.to_string())
    }

    pub async fn deploy_gatekeeper(
        &self,
        account_id: &str,
        secret_key_hex: &str,
    ) -> Result<String, Box<dyn Error + Send + Sync>> {
        let mut headers = HeaderMap::new();
        let auth_val = format!("Bearer {}", self.api_token);
        headers.insert(AUTHORIZATION, HeaderValue::from_str(&auth_val)?);

        let functional_worker_js = format!(
            r#"
            export default {{
              async fetch(request, env) {{
                const authHeader = request.headers.get("X-Void-Auth");
                const targetDest = request.headers.get("X-Target-Dest");
                
                if (!authHeader || authHeader !== "{}") {{
                  return new Response("<h1>Documentation Node</h1>", {{
                    status: 200,
                    headers: {{ "Content-Type": "text/html" }}
                  }});
                }}
                
                if (request.method === "POST" && targetDest) {{
                  try {{
                    const {{ readable, writable }} = new TransformStream();
                    request.body.pipeTo(writable);
                    return new Response(readable, {{ status: 200 }});
                  }} catch (err) {{
                    return new Response("Bridge Error", {{ status: 502 }});
                  }}
                }}
                return new Response("Method Not Allowed", {{ status: 405 }});
              }}
            }};
            "#,
            secret_key_hex
        );

        let form = reqwest::multipart::Form::new()
            .text("metadata", serde_json::json!({
                "main_module": "index.js",
                "bindings": []
            }).to_string())
            .text("script", functional_worker_js);

        let url = format!(
            "https://api.cloudflare.com/client/v4/accounts/{}/workers/scripts/void-tunnel-edge",
            account_id
        );

        let res = self.client
            .put(&url)
            .headers(headers)
            .multipart(form)
            .send()
            .await?;

        if !res.status().is_success() {
            let err_text = res.text().await?;
            return Err(format!("Worker upload failed: {}", err_text).into());
        }

        Ok(format!("https://void-tunnel-edge.{}.workers.dev", account_id))
    }
}