// build.rs - Tauri compilation metadata and asset packaging script
fn main() {
    tauri_build::build();
}